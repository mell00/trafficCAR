## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(osmdata)
library(sf)

## ----eval = FALSE-------------------------------------------------------------
# city <- "College Station, Texas, USA"
# 
# q <- opq(city) |>
#   add_osm_feature(key = "highway")
# 
# osm <- osmdata_sf(q)

## ----eval = FALSE-------------------------------------------------------------
# roads <- osm$osm_lines

## ----eval = FALSE-------------------------------------------------------------
# roads <- roads[, c("highway", "name", "geometry")]
# unique(st_geometry_type(roads))

## ----eval = FALSE-------------------------------------------------------------
# st_write(
#   roads,
#   "roads_cstat.geojson",
#   delete_dsn = TRUE,
#   quiet = TRUE
# )

## ----eval = FALSE-------------------------------------------------------------
# library(usethis)
# 
# roads_cstat <- st_read("roads_cstat.geojson", quiet = TRUE)
# use_data(roads_cstat, overwrite = TRUE)

## ----eval = FALSE-------------------------------------------------------------
# data(roads_cstat)

## ----eval = FALSE-------------------------------------------------------------
# library(trafficCAR)
# 
# segs <- roads_to_segments(
#   roads_cstat,
#   split_at_intersections = TRUE
# )
# 
# adj <- build_adjacency(segs)

## ----eval=FALSE---------------------------------------------------------------
# library(sf)
# library(usethis)
# 
# roads_cstat_small <- st_read(
#   "inst/extdata/roads_cstat_small.geojson",
#   quiet = TRUE
# )
# 
# use_data(roads_cstat_small, overwrite = TRUE)

## ----eval=FALSE---------------------------------------------------------------
# segs <- roads_to_segments("roads_cstat.geojson")

