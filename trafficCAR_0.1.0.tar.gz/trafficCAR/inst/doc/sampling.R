## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(trafficCAR)
library(Matrix)

## -----------------------------------------------------------------------------
A_small <- matrix(
  c(0, 1, 0,
    1, 0, 1,
    0, 1, 0),
  nrow = 3,
  byrow = TRUE
)
A_small

## -----------------------------------------------------------------------------
Q_car <- car_precision(A_small, type = "proper", rho = 0.5, tau = 1)
Q_car

## -----------------------------------------------------------------------------
Q_icar <- car_precision(A_small, type = "icar", tau = 1)
Q_icar

## -----------------------------------------------------------------------------
x0 <- trafficCAR:::rmvnorm_prec(Q_car)
x0

## -----------------------------------------------------------------------------
b <- c(1, 0, -1)
x1 <- trafficCAR:::rmvnorm_prec(Q_car, b = b)
x1

## -----------------------------------------------------------------------------
# ICAR precision matrices are singular, so direct Cholesky-based sampling may fail.
# A practical approach for simulation is to add a small ridge and then center.
# This yields an approximate draw on the ICAR subspace.

n_icar <- nrow(Q_icar)
eps <- 1e-6
Q_icar_ridge <- Q_icar + Matrix::Diagonal(n_icar, x = eps)

x_icar <- trafficCAR:::rmvnorm_prec(Q_icar_ridge)
x_icar_centered <- x_icar - mean(x_icar)
x_icar_centered

A_road <- NULL

road_file <- system.file("extdata", "roads.geojson", package = "trafficCAR")
has_roads <- nzchar(road_file) && file.exists(road_file)

has_sf <- requireNamespace("sf", quietly = TRUE)
has_igraph <- requireNamespace("igraph", quietly = TRUE)

if (has_roads && has_sf && has_igraph) {
  roads_sf <- sf::st_read(road_file, quiet = TRUE)

  # use build_network() if available; otherwise, adjacency must be created by user code.
  has_build_network <- exists("build_network", where = asNamespace("trafficCAR"), inherits = FALSE)

  if (has_build_network) {
    net <- trafficCAR::build_network(roads_sf)

    # try common outputs; otherwise construct from an edge list.
    if (is.list(net) && "A" %in% names(net)) {
      A_road <- net$A
    } else if (is.list(net) && "adjacency" %in% names(net)) {
      A_road <- net$adjacency
    } else if (is.list(net) && "edges" %in% names(net)) {
      edges <- net$edges
      g <- igraph::graph_from_data_frame(edges[, c("from", "to")], directed = FALSE)
      A_road <- igraph::as_adjacency_matrix(g, sparse = TRUE, attr = NULL)
    }
  }
}

## -----------------------------------------------------------------------------
if (is.null(A_road)) {
  # nodes: 1--2--3 and 2--4 (T-junction at node 2)
  edges <- matrix(c(
    1, 2,
    2, 3,
    2, 4
  ), ncol = 2, byrow = TRUE)

  if (requireNamespace("igraph", quietly = TRUE)) {
    g <- igraph::graph_from_edgelist(edges, directed = FALSE)
    A_road <- igraph::as_adjacency_matrix(g, sparse = TRUE, attr = NULL)
  } else {
    # minimal fallback without igraph (dense, small only)
    n <- max(edges)
    A_road <- matrix(0, n, n)
    for (k in seq_len(nrow(edges))) {
      i <- edges[k, 1]; j <- edges[k, 2]
      A_road[i, j] <- 1
      A_road[j, i] <- 1
    }
    A_road <- Matrix(A_road, sparse = TRUE)
  }
}

c(n = nrow(A_road), nnz = Matrix::nnzero(A_road))

## -----------------------------------------------------------------------------
# proper CAR (users should choose rho consistent with their graph and model)
Q_car_road <- car_precision(A_road, type = "proper", rho = 0.5, tau = 1)

# ICAR
Q_icar_road <- car_precision(A_road, type = "icar", tau = 1)

x_car_road <- trafficCAR:::rmvnorm_prec(Q_car_road)
n_road <- nrow(Q_icar_road)
eps <- 1e-6
Q_icar_road_ridge <- Q_icar_road + Matrix::Diagonal(n_road, x = eps)
x_icar_road <- trafficCAR:::rmvnorm_prec(Q_icar_road_ridge)
x_icar_road <- x_icar_road - mean(x_icar_road)

summary(x_car_road)
summary(x_icar_road)

